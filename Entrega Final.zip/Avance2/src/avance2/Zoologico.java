package avance2;

public class Zoologico {
    //Declaración de los atributos de la clase
    private String nombreZoo;
    private String localidadZoo;
    private int capacidadMaxZoo;
    
    //Declaración del constructor con parámetros
    public Zoologico(String nombreZoo, String localidadZoo, int capacidadMaxZoo) {
        this.nombreZoo = nombreZoo;
        this.localidadZoo = localidadZoo;
        this.capacidadMaxZoo = capacidadMaxZoo;
    }
    //Declaración de los getters/setters (encapsulamiento)
    public String getNombreZoo() {
        return nombreZoo;
    }

    public void setNombreZoo(String nombreZoo) {
        this.nombreZoo = nombreZoo;
    }

    public String getLocalidadZoo() {
        return localidadZoo;
    }

    public void setLocalidadZoo(String localidadZoo) {
        this.localidadZoo = localidadZoo;
    }

    public int getCapacidadMaxZoo() {
        return capacidadMaxZoo;
    }

    public void setCapacidadMaxZoo(int capacidadMaxZoo) {
        this.capacidadMaxZoo = capacidadMaxZoo;
    }
    
    //Metodo para identificar el Zoologico
    public void identificarZoo(String nombreZoo, String localidadZoo){
        this.nombreZoo = nombreZoo;
        this.localidadZoo = localidadZoo;
    }
    
    //Método para establecer la Capacidad maxima del Zoo // se recibe mediante capacidadMaxZoo
    public void establecerCapacidadMax(int capacidadMaxZoo) {
        this.capacidadMaxZoo = capacidadMaxZoo;
    }
    //El metodo toString muestra la informacion ingresada por el usuario
    @Override
    public String toString() {
        return "*** Información del Zoológico ***\n" +
                "Nombre del Zoologico: " + nombreZoo + "\n" +
                "Ubicación: " + localidadZoo + "\n" +
                "Capacidad maxima: " + capacidadMaxZoo + " animales";
        }
    }