package avance2;
//Se importó la libreria JOptionPane para pedir datos y mostrar mensajes en pantalla
import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
        //Mensaje de Bienvenida
        JOptionPane.showMessageDialog(null,"Bienvenido al sistema del Zoológico!" );
        
        //El sistema inicia solicitando los datos del Zoológico
        String nombreZoo = JOptionPane.showInputDialog("Ingrese el nombre del zoológico: ");
        String localidadZoo = JOptionPane.showInputDialog("Ingrese la localidad donde se ubica el zoológico: ");
        int capacidadMaxZoo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la capacidad máxima del zoológico: "));
        Zoologico zoo = new Zoologico(nombreZoo, localidadZoo, capacidadMaxZoo);
        JOptionPane.showMessageDialog(null, zoo.toString());
        
        //Declaro los demás arreglos y variables
        Animales animal [] = new Animales [zoo.getCapacidadMaxZoo()]; //Arreglo de animales
        int totalAnimales = 0;
        Ubicacion[] ubicaciones = new Ubicacion[zoo.getCapacidadMaxZoo()]; //Arreglo para las ubicaciones
        int contador = 0;
        //Se crea una cuadricula de ubicaciones con columas "x" y filas "y"
        for (int x = 0; x < zoo.getCapacidadMaxZoo() && contador < ubicaciones.length; x++){
            for(int y = 0; y < zoo.getCapacidadMaxZoo() && contador < ubicaciones.length; y++){
                ubicaciones[contador] = new Ubicacion(contador + 1, x, y);
                contador++;
            }
        }
    
    //Se utiliza un bucle para que el usuario pueda volver e interactuar facilmente dentro del menú principal
    String opcion = "";
    while (!opcion.equals("7")) {
        opcion = JOptionPane.showInputDialog(
                "*** Menú Principal ***\n" +
                "1)Agregar animal" + "\n" +
                "2)Ubicación animal - por ID" + "\n" +
                "3)Eliminar animal"+ "\n" +
                "4)Buscar animal" + "\n" +
                "5)Mostrar animales registrados" + "\n" +
                "6)Generar reporte" + "\n" +
                "7)Salir"
        );
        //Se utiliza switch/default para navegar en el menú principal
        switch (opcion){
            
            case "1": //Opción para agregar un nuevo animal al sistema
                if(totalAnimales < animal.length){ //Valida si el arreglo aún tiene espacio para agregar animales
                    Animales nuevoAnimal = new Animales();//Se crea un nuevo objeto/animal
                    nuevoAnimal.setNombre(JOptionPane.showInputDialog("Ingrese el nombre del animal: "));
                    nuevoAnimal.setEspecie(JOptionPane.showInputDialog("Ingrese la especie: "));
                    //Para el enum género, se crea una variable que pueda convertir el dato ingresado de String a Género
                    String generoTexto = JOptionPane.showInputDialog("Seleccione el género del animal:\nMamifero\nAve\nReptil\nAnfibio\nPez");
                    Animales.Genero genero = Animales.Genero.valueOf(generoTexto); //Convierte String a Género
                    nuevoAnimal.setGenero(genero);
                    nuevoAnimal.setEdad(Integer.parseInt(JOptionPane.showInputDialog("Ingrese la edad (años): ")));
                    animal[totalAnimales] = nuevoAnimal;
                    totalAnimales++;
                    JOptionPane.showMessageDialog(null, nuevoAnimal.toString() + "\n\nSe agregó correctamente el animal al sistema");
                }
                else{//Opción si la capacidad máxima se ha alcanzado y no se pueden agregar más animales
                    JOptionPane.showMessageDialog(null, "Se ha alcanzado la capacidad máxima de animales");
                }
                break;
                
            case "2"://Opción para asignar/mover de ubicación a un animal 
                //El sistema solicita al usuario el número identificador del animal
                int idAnimal = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número identificador del animal: "));
                //Se crea una variable de control que verifica si el animal existe o no en el sistema
                boolean existe = false;
                //El sistema valida si el animal existe y si el identificador es correcto y coincide
                for(int i = 0; i < totalAnimales; i++){
                    if(animal[i] != null && animal[i].getnumIdentificador() == idAnimal){
                        existe = true;
                        break;
                    }
                }
                //Si el animal no existe o su información es incorrecta, el sistema muestra el siguiente mensaje
                if(!existe){
                    JOptionPane.showMessageDialog(null, "El animal no existe o su identificador es incorrecto");
                    break;
                }
                //Si el animal existe, el sistema busca su ubicación actual
                Ubicacion ubActual = null;
                for(int i = 0; i < ubicaciones.length; i++){
                    if(ubicaciones[i].getIdAnimal() == idAnimal){
                        ubActual = ubicaciones[i];
                        break;
                    }
                }
                //El sistema muestra las ubicaciones disponibles para asignar o mover el animal
                String ubDisponibles = "";
                for(int i = 0; i < ubicaciones.length; i++){
                    if(ubicaciones[i].estadoUbicacion()){
                        ubDisponibles+="ID "+ubicaciones[i].getIdUbicacion()
                                +"\n("+ ubicaciones[i].getCoordenadaX()+","+ubicaciones[i].getCoordenadaY()+")";
                    }
                }
                //El usuario debe elegir una ubicación tanto si va a mover o asignar una nueva ubicación
                //Se crean las variables de control del sistema referentes a la ubicación
                Ubicacion destino = null;
                boolean ubValida = false;
                String mapa = "";
                String entrada = "";
                boolean opCancelada = false;
                
                //Se crea un ciclo para mostrar las ubicaciones Libres/Ocupadas del zoológico
                //Así el uuario puede seleccionar una ubicación válida para asignar o mover
                while (!ubValida){
                    mapa = "Mapa del Zoológico: \n\n";
                    for(int i = 0; i < ubicaciones.length; i++){
                        mapa += "Ubicación " + ubicaciones[i].getIdUbicacion() + " > (" + ubicaciones[i].getCoordenadaX() + 
                                "," + ubicaciones[i].getCoordenadaY() + ") | ";
                        if(ubicaciones[i].estadoUbicacion()){
                            mapa += "Libre\n";
                        }else{
                            mapa += "Ocupado\n";
                        }
                    }
                //Opción si el animal existe y ya tiene ubicación, el sistema muestra solo la opción para moverlo
                if(ubActual != null){
                    entrada = JOptionPane.showInputDialog("El animal cuenta con ubicación\n\n" +
                            "Ubicación actual: " + ubActual.getIdUbicacion() + " > (" + ubActual.getCoordenadaX() + 
                            "," + ubActual.getCoordenadaY() + ")\n\n" + mapa +
                            "\nIngrese el número de la nueva ubicación (Ej 1, 2, 3)\n" + "O\n" + "Escriba 'cancelar' para salir");
                    }
                //Opción si el animal no tiene ubicacion, muestra solo la opción para asignar
                else{
                    entrada = JOptionPane.showInputDialog("El animal no cuenta con ubicación asignada\n\n" + mapa + "\n" +
                            "Ingrese el número de la ubicación (Ej: 1, 2, 3...)\n " + "O\n" + "Escriba 'cancelar' para salir:");
                }
                //Opción si el usuario cancela la operación
                if(entrada == null){
                    break;
                }
                //Valida si el usuario escribio cancelar
                if(entrada.equals("cancelar")){
                    JOptionPane.showMessageDialog(null,"Operación cancelada");
                    opCancelada = true;
                    break;
                }
                int idUbicacion = Integer.parseInt(entrada); //Convierte el ID de string a int
                destino = null; //Reinicia la variable en cada iteración
                //El sistema valida si el ubicación elegida esta libre u ocupada
                for (int i = 0; i < ubicaciones.length; i++){
                    if (ubicaciones[i].getIdUbicacion() == idUbicacion && ubicaciones[i].estadoUbicacion()){
                        destino = ubicaciones[i];
                        ubValida = true;
                        break;
                    }
                }
                //Si el usuario selecciona una ubicación ocupada, se muestra el siguiente mensaje
                if(!ubValida){
                    JOptionPane.showMessageDialog(null, "Ubicación inválida \nDebe elegir una ubicación libre");
                    }
                }
                if(opCancelada){
                    break;
                }
                if(destino != null){//Si el usuario canceló la operación 
                    if(ubActual != null){//Si el usuario movio de ubicación a un animal
                        ubActual.liberarUbicacion();
                        destino.asignarAnimal(idAnimal);
                        JOptionPane.showMessageDialog(null, "El animal ha sido movido de su ubicación existosamente");
                    }else{ //Si el usuario asigno una ubicación a un animal
                    destino.asignarAnimal(idAnimal);
                    JOptionPane.showMessageDialog(null,"Se ha asignado una ubicación al animal exitosamente");
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Ubicación inválida");
                }
                break;
                
            case "3"://Opción para eliminar un animal del sistema
                //El sistema va a pedir que seleccione el tipo de busqueda del animal por eliminar
                String seleccion = JOptionPane.showInputDialog("Desea bucar el animal por: \n1)Nombre \n2)Número identificador: ");
                if (seleccion.equals("1")){//Valida busqueda por nombre
                    String nombreEliminar = JOptionPane.showInputDialog("Ingrese el nombre del animal: ");
                    int idEliminar = -1;//Guarda el ID del animal 
                    for(int i = 0; i < totalAnimales; i++){ //Busca el ID del animal antes de eliminarlo
                        if(animal[i] != null && animal[i].getNombre().equals(nombreEliminar)){
                            idEliminar = animal[i].getnumIdentificador();
                            break;
                        }
                    }
                    totalAnimales = Animales.eliminarAnimal(animal, totalAnimales, nombreEliminar, -1);
                    if(idEliminar != -1){//Elimina solo el ID valído encontrado
                        for(int i= 0; i < ubicaciones.length; i++){
                            if(ubicaciones[i].getIdAnimal() == idEliminar){
                                ubicaciones[i].liberarUbicacion();
                                break;
                            }
                        }
                    }
                    JOptionPane.showMessageDialog(null, "El animal de nombre " + nombreEliminar + " ha sido eliminado");
                }
                else if (seleccion.equals("2")){//Valida busqueda por numIdentificador
                    int idEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número identificador del animal: "));
                    totalAnimales = Animales.eliminarAnimal(animal, totalAnimales,"", idEliminar);
                    for(int i = 0; i < ubicaciones.length; i++){
                        if(ubicaciones[i].getIdAnimal() == idEliminar){
                            ubicaciones[i].liberarUbicacion();
                            break;
                        }
                    }
                    JOptionPane.showMessageDialog(null,"El animal con identificador " + idEliminar + " ha sido eliminado");
                }
                else{
                    JOptionPane.showMessageDialog(null,"Opción inválida \nEl animal no existe");
                }
                break;
                
            case "4"://Opción para buscar un animal en el sistema
                String busqueda = JOptionPane.showInputDialog("Bucar animal por: \n1)Nombre \n2)Número Identificador");
                boolean encontrado = false; //Valida si el animal se encontró registrado
                String resultado; //Variable para mostrar el texto final de resultados
                //1) Busqueda por nombre
                if(busqueda.equals("1")){
                    String buscarNombre = JOptionPane. showInputDialog("Ingrese el nombre del animal: ");
                    resultado = "Resultado de busqueda por nombre: " + buscarNombre + "\n\n"; //Inicializa el mensaje
                    for(int i = 0; i < totalAnimales; i++){ //Busca el nombre ingresado en el arreglo de animales registrados
                        if(animal[i] != null && animal[i].getNombre().equalsIgnoreCase(buscarNombre)){ //Valida que el animal exista y que el nombre coincida con el registrado
                            resultado += animal[i].toString() + "\n";
                            boolean tieneUbicacion = false; //Valida si el animal tiene registrada una ubicación
                            for(int j = 0; j < ubicaciones.length; j++){ //Busca ubicación relacionada con el identificador del animal
                                if(ubicaciones[j].getIdAnimal() == animal[i].getnumIdentificador()){ //Valida que el identificador sea igual en el arreglo ubicaciones y animales
                                    resultado += "Ubicación actual: ID" + ubicaciones[j].getIdUbicacion() + 
                                            " (" + ubicaciones[j].getCoordenadaX() + "," + ubicaciones[j].getCoordenadaY() + ")\n";
                                    tieneUbicacion = true;
                                    break;
                                }
                            }
                            if(!tieneUbicacion){ //Mensaje si el animal no ha sido asignado a una ubicación 
                                resultado += "Ubicación actual: No asignada\n";
                            }
                            resultado += "\n";
                            encontrado = true;
                        }
                    }
                //2) Busqueda por Número Identificador
                }else if(busqueda.equals("2")){
                   int buscarID = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número identificador del animal: "));
                   resultado = "Resultado de busqueda por identificador: " + buscarID + "\n\n"; //Inicializa el mensaje
                   for(int i = 0; i < totalAnimales; i++){ //Busca el numIdentificador ingresado en el arreglo de animales registrados
                       if(animal[i] != null && animal[i].getnumIdentificador() == buscarID){ //Valida que el animal exista y que el identificador coincida con el registrado
                           resultado += animal[i].toString() + "\n";
                           boolean tieneUbicacion = false; //Valida si el animal tiene registrada una ubicación
                           for(int j = 0; j < ubicaciones.length; j++){ //Busca ubicación relacionada con el identificador del animal
                               if(ubicaciones[j].getIdAnimal() == buscarID){ //Valida si la ubicación pertenece al animal buscado
                                   resultado += "Ubicación actual: ID" + ubicaciones[j].getIdUbicacion() + 
                                           " (" + ubicaciones[j].getCoordenadaX() + "," + ubicaciones[j].getCoordenadaY() + ")\n";
                                   tieneUbicacion = true;
                                   break;
                               }
                           }
                           if(!tieneUbicacion){ //Mensaje si el animal no ha sido asignado a una ubicación 
                               resultado += "Ubicación actual: No asignada\n";
                           }
                           encontrado = true;
                           break;
                       }
                   }
                }else{
                    JOptionPane.showMessageDialog(null, "Opción inválida");
                    break;
                }
                if(!encontrado){ //Opción si no se encuentra el animal ni por nombre ni por identificador
                    resultado += "No se enconró ningún animal";
                }
                JOptionPane.showMessageDialog(null, resultado);
                break;
                
            case "5": //Opción para mostrar lista de animales registrados en el sistema
                String lista = "*** Animales Registrados ***\n\n";
                for(int i = 0; i < animal.length; i++){ //Recorre todas las posiciones del arreglo animales
                    lista += "Animal " + (i + 1) + ": "; //Muestra la posición del animal
                    if(animal[i] != null){ //Valida si en esa posición hay un animal registrado
                        lista += "\n" + animal[i].toString() + "\n\n"; //Si existe se muestra su información
                    }else{
                        lista += "Vacío\n\n"; //Mensaje si la posición esta vacía
                    }
                }
                lista += "\n *** Ubicaciones registradas *** \n\n";
                for(int j = 0; j < ubicaciones.length; j++){ //Recorre las ubicaciones del zoológico
                    lista += "Ubicación " + ubicaciones[j].getIdUbicacion() + ": "; //Muestra el ID de la ubicación
                    if(ubicaciones[j].estadoUbicacion()){ //Verifica si la ubicación está libre u ocupada
                        lista += "(" + ubicaciones[j].getCoordenadaX() + "," + //Si esta libre muestra sus coordenadas y el estado
                                ubicaciones[j].getCoordenadaY() + ") Estado: Libre\n"; 
                    }else{ //Si está ocupada muestra coordenadas, estado y ID del animal asignado
                        lista += "(" + ubicaciones[j].getCoordenadaX() + "," + ubicaciones[j].getCoordenadaY() + 
                                ") Estado: Ocupado" + " | Animal ID: " + ubicaciones[j].getIdAnimal() + "\n";
                    }
                }
                JOptionPane.showMessageDialog(null, lista); //Muestra toda la información 
                break;
            case "6"://Opción para generar reporte de animales
                String reporte = "*** Reporte ***\n\n";
                //El reporte muestra primero los datos del zoológico
                reporte += zoo.toString() + "\n\n";
                //Luego muestra el reporte de animales registrados
                if(totalAnimales == 0){ //Valida si existen o no animales registrados
                    reporte += "No hay animales registrados";
                }else{
                    for(int i = 0; i < totalAnimales; i++){ //Recorre el arreglo con los animales registrados
                        if(animal[i] != null){ //Valida que el animal exista en esa posición antes de usarlo
                            reporte += animal[i].toString() + "\n";
                            boolean tieneUbicacion = false; //Validar si el animal posee ubicación
                            for(int j = 0; j < ubicaciones.length; j++){//Recorre las ubicaciones y verifica si alguna contiene el id del animal
                                if(ubicaciones[j].getIdAnimal() == animal[i].getnumIdentificador()){ //Valida si el animal tiene asignada esta ubicación
                                    reporte += "Ubicación: ID" + ubicaciones[j].getIdUbicacion() + 
                                            " (" + ubicaciones[j].getCoordenadaX() + ", " + ubicaciones[j].getCoordenadaY() + ")\n";
                                    tieneUbicacion = true;
                                    break;
                                }
                            }
                            if(!tieneUbicacion){ //Valida si el animal no tiene una ubicación asignada
                                reporte += "Ubicación: No Asignada\n";
                            }
                            reporte += "\n"; //Deja una línea en blanco entre animales
                        }
                    }
                }
                //Después muestra el estado completo de todas las ubicaciones del zoológico.
                reporte += "Mapa de Ubicaciones\n";
                for(int i = 0; i < ubicaciones.length; i++){ //Recorre cada ubicación para mostrar sus coordenadas en el mapa
                    reporte += "(" + ubicaciones[i].getCoordenadaX() + ", " + ubicaciones[i].getCoordenadaY() + ") ";
                    if(ubicaciones[i].estadoUbicacion()){ //Valida el estado de la ubicacion (Libre/Ocupado)
                        reporte += "Libre\t";
                    }else{
                        reporte += "Ocupado\t";
                    }
                    if((i + 1) % 3 == 0){ //Inserta un salto de línea cada 3 ubicaciones para formar la cuadrícula
                        reporte += "\n";
                    }
                }
                JOptionPane.showMessageDialog(null, reporte); //Muestra el reporte completo
                break;
                
            case "7"://Opción para salir del sistema
                JOptionPane.showMessageDialog(null,"Gracias por utilizar nuestro sistema! \nFin del programa.");
                break;
                
            default://Usuario selecciona una opción diferente a las del menú
                JOptionPane.showMessageDialog(null,"Opción inválida");
            }
        }
    }
}
