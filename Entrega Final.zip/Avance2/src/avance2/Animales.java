package avance2;
//Importo la librería java.Random para generar automáticamete el número de cédula de la persona 
import java.util.Random;

public class Animales {
    
    //Declaro un tipo de dato con enumeración que asegura el uso de valores válidos
    //Esta herramienta se utiliza en el método que asigna el sector donde ubicar al animal
    public enum Genero{
        Mamifero, 
        Ave,
        Reptil,
        Anfibio, 
        Pez;
    }

    //Declaración de los atributos de la clase
    private String nombre;
    private String especie;
    private Genero genero;
    private int edad;
    private final int numIdentificador;
    
    //Declaración del Constructor
    //Los demás atributos se les asigna el valor en la clase main por el usuario
    public Animales() {
        this.numIdentificador = identificador();
    }
    
    //Declaración de los getters/setters (encapsulamiento)
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    public int getnumIdentificador() {
        return numIdentificador;
    }
    public void setGenero(Genero genero) {
    this.genero = genero;
    }
    
    //Método privado 
    //Asigna aleatoriamente el número de indetificador del animal
    private int identificador(){
        Random random = new Random(); //Creo el objeto que genera los números aleatorios
        return 100 + random.nextInt(9000);
    }
    //Métodos públicos
    //1) Método para asignar el sector según su género (Mamífero, Ave, Reptil, Anfibio, Pez)
    public String asignarSector(){
        switch (genero){
            case Mamifero:
                return "Sector Mamíferos";
            case Ave:
                return "Sector Aves";
            case Reptil:
                return "Sector Reptiles";
            case Anfibio:
                return "Sector Anfibios";
            case Pez:
                return "Sector Peces";
            default:
                return "Error - Sector no asignado";
        }
    }  
    //2) Método para agregar un nuevo animal al sistema
    //Este método es el encargado de crear cada objeto/animal, que luego que guarad en el main en un arrgelo de objetos
    public static Animales agregarAnimal(String nombre, String especie, Genero genero, int edad, int numIdentificador){
        Animales nuevoAnimal = new Animales ();
        return nuevoAnimal;
    }
    //3) Método para eliminar animal del sistema
    public static int eliminarAnimal(Animales[]animal, int totalAnimales, String nombre, int numIdentificador){
        for (int i = 0; i < totalAnimales; i++){//Primer for recorre el arreglo
        //Este if valida que el arreglo tenga al menos 1 objeto y verifica el nombre o identifiacor del animal
            if (animal[i] != null && 
                (animal[i].getNombre().equals(nombre)||
                 animal[i].getnumIdentificador()== numIdentificador)){
            //Si el animal existe se usa un segundo for que mueve los animales de posición y llenar el espacio del animal eliminado
                for (int j = i; j < totalAnimales - 1; j++){
                    animal[j] = animal[j + 1];
                }
                animal[totalAnimales - 1] = null; //Limpia la última posición
                return totalAnimales - 1; //Devuelve el nuevo total de animales menos el eliminado
            }
        }
        //Si el animal no existe  en el sistema
            return totalAnimales; //Duevuelve el total de animales sin modificación
    }
    
    //Método toString
    @Override
    public String toString() {
        return "*** Animal registrado ***\n" 
                + "\nNombre: " + nombre 
                + "\nEspecie: " + especie 
                + "\nGénero: " + genero 
                + "\nEdad: " + edad + " años"
                + "\nNúmero de identificador: " + numIdentificador
                + "\nSector asignado: " + asignarSector();
    }
}

