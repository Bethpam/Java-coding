package avance2;

// Clase que representa una ubicación dentro del zoológico
public class Ubicacion {

    //Declaración de los atributos de la clase
    private int idUbicacion;
    private int coordenadaX;
    private int coordenadaY;
    private boolean ocupado;
    private int idAnimal;

    //Declaración del Constructor
    public Ubicacion(int idUbicacion, int x, int y) {
        this.idUbicacion = idUbicacion;
        this.coordenadaX = x;
        this.coordenadaY = y;
        this.ocupado = false;   // Por defecto la ubicación inicia libre
        this.idAnimal = -1;      // -1 indica que no hay animal
    }

    //Declaración de los getters (encapsulamiento)
    public int getIdUbicacion() {
        return idUbicacion;
    }

    public int getCoordenadaX() {
        return coordenadaX;
    }

    public int getCoordenadaY() {
        return coordenadaY;
    }

    public boolean isOcupado() {
        return ocupado;
    }

    public int getIdAnimal() {
        return idAnimal;
    }

    //Método para saber el estado (libre/ocupado) de la ubicación
    public boolean estadoUbicacion(){
        return !ocupado;
    }
    
    // Método para asignar un animal a la ubicación
    public void asignarAnimal(int idAnimal) {
        this.idAnimal = idAnimal;
        this.ocupado = true;
    }

    // Método para liberar la ubicación
    public void liberarUbicacion() {
        this.idAnimal = -1;
        this.ocupado = false;
    }

    // Método para mostrar la información
    @Override
    public String toString() {
        return "Ubicacion: " + idUbicacion +
               " (" + coordenadaX + "," + coordenadaY + ")" +
               " Estado: " + (ocupado ? "Ocupado" : "Libre")+
               " Animal: " + idAnimal;
    }
}